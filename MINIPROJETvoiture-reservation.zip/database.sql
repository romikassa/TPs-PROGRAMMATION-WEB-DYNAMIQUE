CREATE DATABASE IF NOT EXISTS reservation_voiture;
USE reservation_voiture;

CREATE TABLE reservations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    marque VARCHAR(50),
    modele VARCHAR(50),
    couleur VARCHAR(30),
    transmission VARCHAR(20),
    date_reservation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

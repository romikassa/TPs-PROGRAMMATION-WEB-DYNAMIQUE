<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Réserver une voiture</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Réserver une voiture</h2>
<form action="submit.php" method="POST">
    <label>Marque :
        <select name="marque" required>
            <option value="Toyota">Toyota</option>
            <option value="Renault">Renault</option>
            <option value="BMW">BMW</option>
        </select>
    </label>

    <label>Modèle :
        <select name="modele" required>
            <option value="Yaris">Yaris</option>
            <option value="Clio">Clio</option>
            <option value="Série 3">Série 3</option>
        </select>
    </label>

    <label>Couleur :
        <select name="couleur" required>
            <option value="Noir">Noir</option>
            <option value="Blanc">Blanc</option>
            <option value="Rouge">Rouge</option>
        </select>
    </label>

    <label>Transmission :
        <select name="transmission" required>
            <option value="Manuelle">Manuelle</option>
            <option value="Automatique">Automatique</option>
        </select>
    </label>

    <button type="submit">Réserver</button>
</form>
</body>
</html>

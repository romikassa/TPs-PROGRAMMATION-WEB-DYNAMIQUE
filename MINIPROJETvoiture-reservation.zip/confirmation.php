<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Succès</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="success">
    <h2>Votre réservation a été enregistrée avec succès !</h2>
    <a href="reservations.php">Voir toutes les réservations</a>
</div>
</body>
</html>

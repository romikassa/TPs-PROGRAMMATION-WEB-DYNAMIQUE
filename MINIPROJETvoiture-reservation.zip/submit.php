<?php
require 'db.php';

$marque = $_POST['marque'];
$modele = $_POST['modele'];
$couleur = $_POST['couleur'];
$transmission = $_POST['transmission'];

$stmt = $pdo->prepare("INSERT INTO reservations (marque, modele, couleur, transmission) VALUES (?, ?, ?, ?)");
$stmt->execute([$marque, $modele, $couleur, $transmission]);

header("Location: confirmation.php");
exit();
?>

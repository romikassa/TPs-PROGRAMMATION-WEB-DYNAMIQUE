<?php
require 'db.php';
$reservations = $pdo->query("SELECT * FROM reservations ORDER BY date_reservation DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Réservations</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Liste des réservations</h2>
<table border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Marque</th>
        <th>Modèle</th>
        <th>Couleur</th>
        <th>Transmission</th>
        <th>Date</th>
    </tr>
    <?php foreach ($reservations as $r): ?>
    <tr>
        <td><?= $r['id'] ?></td>
        <td><?= htmlspecialchars($r['marque']) ?></td>
        <td><?= htmlspecialchars($r['modele']) ?></td>
        <td><?= htmlspecialchars($r['couleur']) ?></td>
        <td><?= htmlspecialchars($r['transmission']) ?></td>
        <td><?= $r['date_reservation'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>
</body>
</html>

<?php
$pdo = new PDO("mysql:host=localhost;dbname=reservation_voiture", "root", "", [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);
?>
